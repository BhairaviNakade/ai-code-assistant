from flask import Flask, request
import subprocess
from sklearn.metrics.pairwise import cosine_similarity
import joblib
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
model_path = "../mini_project/model"


# Load saved files

vectorizer = joblib.load(r"C:\Users\sshuser\Desktop\project\vectorizer.pkl")
query_vectors = joblib.load(r"C:\Users\sshuser\Desktop\project\query_vectors.pkl")
queries = joblib.load(r"C:\Users\sshuser\Desktop\project\queries.pkl")
codes = joblib.load(r"C:\Users\sshuser\Desktop\project\codes.pkl")
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForSeq2SeqLM.from_pretrained(model_path)


def ai_generate(prompt):
    print("inside generating function")
    # prompt = "### Task: Write Python code to add 2 numbers\n### Code:\n"

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    outputs = model.generate(
        **inputs,
        max_new_tokens=256,
        do_sample=True,
        temperature=0.7,
        top_k=50,
        top_p=0.95,
        repetition_penalty=1.1,
        pad_token_id=tokenizer.eos_token_id  # optional but helps
    )

    code = tokenizer.decode(outputs[0], skip_special_tokens=True)
    with open(r"C:\Users\sshuser\Desktop\input.txt","w+") as file:
        file.write(code)
        
    run_ahk()
    return "Done baby"


def run_ahk():
    ahk_exe = r"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
    ahk_script = r"C:\Users\sshuser\Desktop\test.ahk"

    subprocess.run(
        [
            "powershell", 
            "-Command", 
            '& "C:\\Program Files\\AutoHotkey\\v2\\AutoHotkey64.exe" "C:\\Users\\sshuser\\Desktop\\test.ahk"'
        ],
        shell=True
    )

def search_ahk(prompt):
    ahk_exe = r"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
    ahk_script = r"C:\Users\sshuser\Desktop\test.ahk"
    
    with open(r"C:\Users\sshuser\Desktop\input.txt","w+") as file:
        file.write(prompt[6:])

    subprocess.run(
        [
            "powershell", 
            "-Command", 
            '& "C:\\Program Files\\AutoHotkey\\v2\\AutoHotkey64.exe" "C:\\Users\\sshuser\\Desktop\\search_test.ahk"'
        ],
        shell=True
    )



def get_code(user_query):
    user_vector = vectorizer.transform([user_query])
    similarities = cosine_similarity(user_vector, query_vectors)
    best_match_idx = similarities.argmax()
    
    code = codes[best_match_idx]  # Return best matching code snippet
    
    with open(r"C:\Users\sshuser\Desktop\input.txt","w+") as file:
        file.write(code)
    
    run_ahk()
    return "Done baby"



app = Flask(__name__)

@app.route('/')
def home():
    prompt = request.args.get('prompt', 'print a error message')
    
    if prompt[:8] == "generate":
        my_prompt = f"### Task: {prompt}\n### Code:\n"
        ai_generate(my_prompt)
    elif prompt[:6] == "search":
        search_ahk(prompt)
    else:
        get_code(prompt)
    # query = prompt
    # print("got prompt")
    # # ai_generate(query)
    
    return "Code ran yayyyyy"


if __name__ == '__main__':
    app.run(debug=True)
